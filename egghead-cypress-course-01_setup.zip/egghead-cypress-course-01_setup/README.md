# Painless end-to-end integration testing with Cypress

This repository contains the course code for my egghead.io course teaching how to test an application using [Cypress.io](https://cypress.io).
