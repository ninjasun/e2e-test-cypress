describe('Simple test', () => {
  it('Works', () => {
    expect(true).to.equal(true)
  })
})
